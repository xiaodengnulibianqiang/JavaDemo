# Java安全

```java
Mavenn 安装配置
多模块项目是什么
了解Gradle
```

```java
Servlet Tomcat  JSP
Spring Boot
```

```java
反射调用方法
反射修改字段
反射修改 final的问题
```

```java
JNDI 攻击

8u101以下如何攻击
8u191以上如何打 (反序列化/本地工程)
审计这些逻辑
```

```java
RMI 攻击

```

```java
Java Agent

RASP原理 简单实现

```

```java
JMX监控  JDWP调试 熟悉利用

```

```java
反序列基础   java assist asm

```
